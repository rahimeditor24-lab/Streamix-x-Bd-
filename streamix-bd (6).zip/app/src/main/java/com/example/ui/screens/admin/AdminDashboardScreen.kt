package com.example.ui.screens.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.Announcement
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.ContentRequest
import com.example.data.model.DashboardStats
import com.example.data.model.Episode
import com.example.data.model.User
import com.example.data.repository.StreamixRepository
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.components.GlassTextField
import com.example.ui.theme.AmberRating
import com.example.ui.theme.CoralRed
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepIndigoBg
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlassCardBorder
import com.example.ui.theme.GlassSurfaceDark
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyanGradient
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VibrantPurple
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminDashboardScreen(
    repository: StreamixRepository,
    onNavigateBackToApp: () -> Unit,
    onLogoutAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUser by repository.currentUser.collectAsStateWithLifecycle()

    // Authorization & Authentication Guard
    if (currentUser?.role?.equals("ADMIN", ignoreCase = true) != true) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MidnightBlack)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(CoralRed.copy(alpha = 0.15f))
                        .border(2.dp, CoralRed, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Access Denied",
                        tint = CoralRed,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Admin Access Denied",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "This area is strictly restricted to Streamix BD administrators. Your account does not have sufficient privileges.",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                GlassButton(
                    text = "Return to Main App",
                    icon = Icons.AutoMirrored.Filled.ArrowBack,
                    onClick = onNavigateBackToApp,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        return
    }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Overview & Stats", "Announcements 📢", "Content CMS", "Homepage & Banners", "User Requests", "User Accounts", "Categories", "System Settings")

    // Data streams
    var stats by remember { mutableStateOf(DashboardStats()) }
    val allAnnouncements by repository.getAllAnnouncementsAdmin().collectAsStateWithLifecycle(emptyList())
    val allContent by repository.getAllContentAdmin().collectAsStateWithLifecycle(emptyList())
    val allRequests by repository.getAllRequestsAdmin().collectAsStateWithLifecycle(emptyList())
    val allUsers by repository.getAllUsersAdmin().collectAsStateWithLifecycle(emptyList())
    val allCategories by repository.getCategories().collectAsStateWithLifecycle(emptyList())

    // Refresh stats
    fun refreshStats() {
        scope.launch {
            stats = repository.getDashboardStats()
        }
    }

    LaunchedEffect(Unit) {
        refreshStats()
    }

    // Dialog States
    var showAddEditAnnouncementDialog by remember { mutableStateOf(false) }
    var editingAnnouncement by remember { mutableStateOf<Announcement?>(null) }

    var showAddEditContentDialog by remember { mutableStateOf(false) }
    var editingContentItem by remember { mutableStateOf<ContentItem?>(null) }

    var showRequestFeedbackDialog by remember { mutableStateOf(false) }
    var selectedRequestForFeedback by remember { mutableStateOf<ContentRequest?>(null) }
    var feedbackActionType by remember { mutableStateOf("APPROVED") } // APPROVED, REJECTED, COMPLETED

    var showAddCategoryDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(28.dp))

            // Admin Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(PurpleCyanGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = MidnightBlack,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Streamix CMS Master",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Bangladeshi OTT Content Administration",
                            color = NeonCyan,
                            fontSize = 10.sp
                        )
                    }
                }

                Row {
                    IconButton(onClick = onNavigateBackToApp) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "User App",
                            tint = TextSecondary
                        )
                    }
                    IconButton(onClick = onLogoutAdmin) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Logout",
                            tint = CoralRed
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Navigation Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkNavyBg,
                contentColor = NeonCyan,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    if (selectedTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = NeonCyan,
                            height = 3.dp
                        )
                    }
                }
            ) {
                tabTitles.forEachIndexed { index, title ->
                    val badgeCount = when (index) {
                        1 -> allAnnouncements.count { it.isActive }
                        2 -> allContent.size
                        3 -> allContent.count { it.isFeatured }
                        4 -> allRequests.count { it.status == "PENDING" }
                        5 -> allUsers.size
                        else -> 0
                    }

                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == index) NeonCyan else TextSecondary,
                                    fontSize = 12.sp
                                )
                                if (badgeCount > 0) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(if (index == 4) CoralRed else if (index == 1) EmeraldGreen else VibrantPurple)
                                            .padding(horizontal = 5.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "$badgeCount",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                when (selectedTab) {
                    0 -> AdminOverviewTab(
                        stats = stats,
                        allContent = allContent,
                        allRequests = allRequests,
                        onAddNewContent = {
                            editingContentItem = null
                            showAddEditContentDialog = true
                        },
                        onGoToRequests = { selectedTab = 4 },
                        onGoToAnnouncements = { selectedTab = 1 },
                        onRefresh = { refreshStats() }
                    )
                    1 -> AdminAnnouncementsTab(
                        announcements = allAnnouncements,
                        onAddNew = {
                            editingAnnouncement = null
                            showAddEditAnnouncementDialog = true
                        },
                        onEdit = { ann ->
                            editingAnnouncement = ann
                            showAddEditAnnouncementDialog = true
                        },
                        onDelete = { id ->
                            scope.launch {
                                repository.deleteAnnouncement(id)
                                refreshStats()
                                snackbarHostState.showSnackbar("Announcement deleted successfully")
                            }
                        },
                        onToggleActive = { id, currentActive ->
                            scope.launch {
                                repository.toggleAnnouncementStatus(id, !currentActive)
                                refreshStats()
                                snackbarHostState.showSnackbar(
                                    if (!currentActive) "Announcement published to Users' Home Screen" else "Announcement unpublished (Inactive)"
                                )
                            }
                        }
                    )
                    2 -> AdminContentListTab(
                        allContent = allContent,
                        onAddNew = {
                            editingContentItem = null
                            showAddEditContentDialog = true
                        },
                        onEdit = { item ->
                            editingContentItem = item
                            showAddEditContentDialog = true
                        },
                        onDelete = { id ->
                            scope.launch {
                                repository.deleteContent(id)
                                refreshStats()
                                snackbarHostState.showSnackbar("Content deleted successfully")
                            }
                        },
                        onTogglePublish = { id, current ->
                            scope.launch {
                                repository.togglePublishContent(id, !current)
                                refreshStats()
                            }
                        },
                        onToggleFeatured = { id, current ->
                            scope.launch {
                                repository.toggleFeaturedContent(id, !current)
                            }
                        },
                        onToggleTrending = { id, current ->
                            scope.launch {
                                repository.toggleTrendingContent(id, !current)
                            }
                        }
                    )
                    3 -> AdminBannersHomepageTab(
                        allContent = allContent,
                        onToggleFeatured = { id, current ->
                            scope.launch {
                                repository.toggleFeaturedContent(id, !current)
                                refreshStats()
                                snackbarHostState.showSnackbar(if (!current) "Promoted to Homepage Hero Banner" else "Removed from Homepage Hero Banner")
                            }
                        },
                        onToggleTrending = { id, current ->
                            scope.launch {
                                repository.toggleTrendingContent(id, !current)
                                refreshStats()
                                snackbarHostState.showSnackbar(if (!current) "Added to Trending Rail" else "Removed from Trending Rail")
                            }
                        }
                    )
                    4 -> AdminRequestsTab(
                        requests = allRequests,
                        onOpenFeedback = { req, action ->
                            selectedRequestForFeedback = req
                            feedbackActionType = action
                            showRequestFeedbackDialog = true
                        },
                        onDelete = { id ->
                            scope.launch {
                                repository.deleteRequest(id)
                                refreshStats()
                                snackbarHostState.showSnackbar("Request deleted")
                            }
                        }
                    )
                    5 -> AdminUsersTab(
                        users = allUsers,
                        onToggleStatus = { user ->
                            scope.launch {
                                repository.toggleUserStatus(user.id, user.status)
                                refreshStats()
                                snackbarHostState.showSnackbar("User status updated: ${if (user.status == "ACTIVE") "SUSPENDED" else "ACTIVE"}")
                            }
                        }
                    )
                    6 -> AdminCategoriesTab(
                        categories = allCategories,
                        onAddCategory = { showAddCategoryDialog = true },
                        onDeleteCategory = { id ->
                            scope.launch {
                                repository.deleteCategory(id)
                                snackbarHostState.showSnackbar("Category deleted")
                            }
                        }
                    )
                    7 -> AdminSettingsTab(
                        currentUser = currentUser,
                        stats = stats,
                        onPurgeCache = {
                            scope.launch {
                                snackbarHostState.showSnackbar("Edge CDN & Image cache purged successfully")
                            }
                        }
                    )
                }
            }
        }

        // Add / Edit Announcement Dialog
        if (showAddEditAnnouncementDialog) {
            AddEditAnnouncementDialog(
                initialAnnouncement = editingAnnouncement,
                onDismiss = { showAddEditAnnouncementDialog = false },
                onSave = { newAnnouncement ->
                    scope.launch {
                        repository.saveAnnouncement(newAnnouncement)
                        showAddEditAnnouncementDialog = false
                        refreshStats()
                        snackbarHostState.showSnackbar(
                            if (editingAnnouncement == null) "Announcement published successfully to Firestore!" else "Announcement updated successfully"
                        )
                    }
                }
            )
        }

        // Add / Edit Content Dialog
        if (showAddEditContentDialog) {
            AddEditContentDialog(
                initialItem = editingContentItem,
                categories = allCategories,
                onDismiss = { showAddEditContentDialog = false },
                onSave = { newItem, episodes ->
                    scope.launch {
                        repository.saveContent(newItem, episodes)
                        showAddEditContentDialog = false
                        refreshStats()
                        snackbarHostState.showSnackbar(if (editingContentItem == null) "New title added to Streamix library" else "Content updated")
                    }
                }
            )
        }

        // Request Feedback Dialog
        if (showRequestFeedbackDialog && selectedRequestForFeedback != null) {
            val req = selectedRequestForFeedback!!
            AdminRequestFeedbackDialog(
                request = req,
                actionType = feedbackActionType,
                onDismiss = { showRequestFeedbackDialog = false },
                onSubmit = { feedbackText ->
                    scope.launch {
                        repository.updateRequestStatus(req.id, feedbackActionType, feedbackText)
                        showRequestFeedbackDialog = false
                        refreshStats()
                        snackbarHostState.showSnackbar("Request status updated to $feedbackActionType")
                    }
                }
            )
        }

        // Add Category Dialog
        if (showAddCategoryDialog) {
            AddCategoryDialog(
                onDismiss = { showAddCategoryDialog = false },
                onSave = { name, slug ->
                    scope.launch {
                        val cat = Category(
                            id = "cat_${UUID.randomUUID().toString().take(6)}",
                            name = name,
                            slug = slug
                        )
                        repository.saveCategory(cat)
                        showAddCategoryDialog = false
                        snackbarHostState.showSnackbar("Category created")
                    }
                }
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// -----------------------------------------------------------------------------------------
// TAB 1: Admin Overview
// -----------------------------------------------------------------------------------------
@Composable
fun AdminOverviewTab(
    stats: DashboardStats,
    allContent: List<ContentItem>,
    allRequests: List<ContentRequest>,
    onAddNewContent: () -> Unit,
    onGoToRequests: () -> Unit,
    onGoToAnnouncements: () -> Unit,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "System Metrics & Activity",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onRefresh) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh stats",
                    tint = NeonCyan
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Key Metric Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminMetricCard(
                title = "Total Catalog",
                value = "${stats.totalVideos}",
                subtitle = "${stats.totalMovies} Movies • ${stats.totalNatok} Natoks",
                accentColor = NeonCyan,
                modifier = Modifier.weight(1f)
            )
            AdminMetricCard(
                title = "Subscribers",
                value = "${stats.totalUsers}",
                subtitle = "${stats.activeUsers} Active Subscribers",
                accentColor = EmeraldGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminMetricCard(
                title = "Stream Views",
                value = "${stats.totalViews / 1000}k+",
                subtitle = "Active Player Sessions",
                accentColor = VibrantPurple,
                modifier = Modifier.weight(1f)
            )
            AdminMetricCard(
                title = "Announcements",
                value = "${stats.activeAnnouncements}",
                subtitle = "${stats.totalAnnouncements} Total Announcements",
                accentColor = NeonCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminMetricCard(
                title = "Pending Requests",
                value = "${stats.pendingRequests}",
                subtitle = "User Wishlist Queue",
                accentColor = if (stats.pendingRequests > 0) AmberRating else TextSecondary,
                modifier = Modifier.weight(1f)
            )
            AdminMetricCard(
                title = "Downloads",
                value = "${stats.totalDownloads}",
                subtitle = "Offline Cached Media",
                accentColor = EmeraldGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Actions
        Text(
            text = "FAST OPERATIONS",
            color = VibrantPurple,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassButton(
                text = "Add Video",
                icon = Icons.Default.Add,
                onClick = onAddNewContent,
                modifier = Modifier.weight(1f),
                testTag = "admin_add_content_quick_btn"
            )
            GlassButton(
                text = "Broadcast 📢",
                icon = Icons.Default.Campaign,
                onClick = onGoToAnnouncements,
                modifier = Modifier.weight(1f)
            )
            GlassButton(
                text = "Requests",
                icon = Icons.Default.PostAdd,
                onClick = onGoToRequests,
                isPrimary = false,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Content Breakdown Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurfaceDark
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Library Breakdown by Genre & Type",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                listOf(
                    Triple("Bangla Natoks & Telefilms", stats.totalNatok, VibrantPurple),
                    Triple("Bangladeshi Cinema & Films", stats.totalFilms + stats.totalMovies, NeonCyan),
                    Triple("Web & Drama Series", stats.totalSeries, AmberRating)
                ).forEach { (label, count, color) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(color)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = label, color = TextSecondary, fontSize = 12.sp)
                        }
                        Text(
                            text = "$count titles",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun AdminMetricCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier,
        backgroundColor = DeepIndigoBg,
        borderColor = accentColor.copy(alpha = 0.35f)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = accentColor,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = TextMuted,
                fontSize = 10.sp
            )
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 2: Content List (CMS)
// -----------------------------------------------------------------------------------------
@Composable
fun AdminContentListTab(
    allContent: List<ContentItem>,
    onAddNew: () -> Unit,
    onEdit: (ContentItem) -> Unit,
    onDelete: (String) -> Unit,
    onTogglePublish: (String, Boolean) -> Unit,
    onToggleFeatured: (String, Boolean) -> Unit,
    onToggleTrending: (String, Boolean) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterType by remember { mutableStateOf("ALL") }

    val filteredContent = remember(allContent, searchQuery, filterType) {
        allContent.filter { item ->
            val matchesQuery = searchQuery.isBlank() ||
                    item.title.contains(searchQuery, ignoreCase = true) ||
                    item.genre.contains(searchQuery, ignoreCase = true)
            val matchesType = filterType == "ALL" || item.type.equals(filterType, ignoreCase = true)
            matchesQuery && matchesType
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            GlassTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = "Search catalog...",
                leadingIcon = Icons.Default.Search,
                modifier = Modifier.weight(1f),
                testTag = "admin_search_content_input"
            )

            Spacer(modifier = Modifier.width(8.dp))

            GlassButton(
                text = "Add",
                icon = Icons.Default.Add,
                onClick = onAddNew,
                testTag = "admin_add_content_btn"
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Type filter pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "NATOK", "MOVIE", "SERIES", "FILM").forEach { type ->
                val isSelected = filterType == type
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .then(
                            if (isSelected) Modifier.background(PurpleCyanGradient)
                            else Modifier.background(GlassSurfaceDark)
                        )
                        .clickable { filterType = type }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = type,
                        color = if (isSelected) MidnightBlack else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Showing ${filteredContent.size} of ${allContent.size} entries",
            color = TextMuted,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("admin_content_list"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredContent, key = { it.id }) { item ->
                AdminContentItemCard(
                    item = item,
                    onEdit = { onEdit(item) },
                    onDelete = { onDelete(item.id) },
                    onTogglePublish = { onTogglePublish(item.id, item.isPublished) },
                    onToggleFeatured = { onToggleFeatured(item.id, item.isFeatured) },
                    onToggleTrending = { onToggleTrending(item.id, item.isTrending) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
fun AdminContentItemCard(
    item: ContentItem,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onTogglePublish: () -> Unit,
    onToggleFeatured: () -> Unit,
    onToggleTrending: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = GlassSurfaceDark
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Poster
                Box(
                    modifier = Modifier
                        .size(width = 54.dp, height = 76.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(DeepIndigoBg)
                ) {
                    AsyncImage(
                        model = item.posterUrl,
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Details
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.title,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (item.isPublished) EmeraldGreen.copy(alpha = 0.2f) else CoralRed.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (item.isPublished) "PUBLISHED" else "DRAFT",
                                color = if (item.isPublished) EmeraldGreen else CoralRed,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${item.type} • ${item.genre} • ${item.releaseYear} • ${item.durationMinutes}m",
                        color = NeonCyan,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "${item.viewsCount} views • ★ ${item.rating}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = GlassCardBorder.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Toggles
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Featured star
                    IconButton(onClick = onToggleFeatured, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (item.isFeatured) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "Toggle Featured",
                            tint = if (item.isFeatured) AmberRating else TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Visibility toggle
                    IconButton(onClick = onTogglePublish, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (item.isPublished) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle Publish",
                            tint = if (item.isPublished) NeonCyan else TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = CoralRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Content Title?", color = TextPrimary) },
            text = { Text("Are you sure you want to permanently delete '${item.title}' from Streamix BD?", color = TextSecondary) },
            containerColor = DarkNavyBg,
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    onDelete()
                }) {
                    Text("Delete Permanently", color = CoralRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

// -----------------------------------------------------------------------------------------
// TAB 3: User Requests Hub
// -----------------------------------------------------------------------------------------
@Composable
fun AdminRequestsTab(
    requests: List<ContentRequest>,
    onOpenFeedback: (ContentRequest, String) -> Unit,
    onDelete: (String) -> Unit
) {
    var filterStatus by remember { mutableStateOf("ALL") }

    val filtered = remember(requests, filterStatus) {
        if (filterStatus == "ALL") requests
        else requests.filter { it.status.equals(filterStatus, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "PENDING", "APPROVED", "COMPLETED", "REJECTED").forEach { status ->
                val isSelected = filterStatus == status
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .then(
                            if (isSelected) Modifier.background(PurpleCyanGradient)
                            else Modifier.background(GlassSurfaceDark)
                        )
                        .clickable { filterStatus = status }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = status,
                        color = if (isSelected) MidnightBlack else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("No requests found in this filter", color = TextSecondary)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("admin_requests_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { req ->
                    AdminRequestCard(
                        request = req,
                        onApprove = { onOpenFeedback(req, "APPROVED") },
                        onReject = { onOpenFeedback(req, "REJECTED") },
                        onComplete = { onOpenFeedback(req, "COMPLETED") },
                        onDelete = { onDelete(req.id) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}

@Composable
fun AdminRequestCard(
    request: ContentRequest,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onComplete: () -> Unit,
    onDelete: () -> Unit
) {
    val statusColor = when (request.status) {
        "APPROVED" -> EmeraldGreen
        "COMPLETED" -> NeonCyan
        "REJECTED" -> CoralRed
        else -> AmberRating
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = GlassSurfaceDark
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = request.title,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Requested by @${request.requestedByUsername} • ${request.contentType}",
                        color = NeonCyan,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusColor.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = request.status,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (request.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = request.description,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            if (request.adminFeedback.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Feedback given: ${request.adminFeedback}",
                    color = AmberRating,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = GlassCardBorder.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.width(6.dp))

                if (request.status == "PENDING") {
                    TextButton(onClick = onReject) {
                        Text("Reject", color = CoralRed, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    TextButton(onClick = onApprove) {
                        Text("Approve", color = EmeraldGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (request.status == "APPROVED") {
                    TextButton(onClick = onComplete) {
                        Text("Mark Available/Completed", color = NeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 4: User Accounts
// -----------------------------------------------------------------------------------------
@Composable
fun AdminUsersTab(
    users: List<User>,
    onToggleStatus: (User) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = remember(users, searchQuery) {
        if (searchQuery.isBlank()) users
        else users.filter { it.username.contains(searchQuery, ignoreCase = true) || it.email.contains(searchQuery, ignoreCase = true) || it.fullName.contains(searchQuery, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        GlassTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = "Search subscribers by name, email, @handle...",
            leadingIcon = Icons.Default.Search,
            testTag = "admin_user_search_input"
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("admin_users_list"),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered, key = { it.id }) { user ->
                AdminUserCard(user = user, onToggleStatus = { onToggleStatus(user) })
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
fun AdminUserCard(
    user: User,
    onToggleStatus: () -> Unit
) {
    val isActive = user.status == "ACTIVE"

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = GlassSurfaceDark
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(DeepIndigoBg)
                ) {
                    AsyncImage(
                        model = user.avatarUrl.ifEmpty { "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300" },
                        contentDescription = user.fullName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = user.fullName,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (user.role == "ADMIN") {
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(VibrantPurple)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("ADMIN", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Text(
                        text = "@${user.username} • ${user.email}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            if (user.role != "ADMIN") {
                TextButton(onClick = onToggleStatus) {
                    Text(
                        text = if (isActive) "Suspend" else "Activate",
                        color = if (isActive) CoralRed else EmeraldGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 5: Categories Management
// -----------------------------------------------------------------------------------------
@Composable
fun AdminCategoriesTab(
    categories: List<Category>,
    onAddCategory: () -> Unit,
    onDeleteCategory: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Streamix BD Hub Categories",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            GlassButton(
                text = "New Category",
                icon = Icons.Default.Add,
                onClick = onAddCategory,
                testTag = "admin_add_category_btn"
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories, key = { it.id }) { cat ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = GlassSurfaceDark
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(PurpleCyanGradient),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Category,
                                    contentDescription = null,
                                    tint = MidnightBlack,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = cat.name, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text(text = "slug: /${cat.slug}", color = NeonCyan, fontSize = 11.sp)
                            }
                        }

                        IconButton(onClick = { onDeleteCategory(cat.id) }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = CoralRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 3: Homepage Banners & Curation Management
// -----------------------------------------------------------------------------------------
@Composable
fun AdminBannersHomepageTab(
    allContent: List<ContentItem>,
    onToggleFeatured: (String, Boolean) -> Unit,
    onToggleTrending: (String, Boolean) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val featuredItems = remember(allContent) { allContent.filter { it.isFeatured } }
    val trendingItems = remember(allContent) { allContent.filter { it.isTrending } }

    val filteredContent = remember(allContent, searchQuery) {
        if (searchQuery.isBlank()) allContent
        else allContent.filter { it.title.contains(searchQuery, ignoreCase = true) || it.type.contains(searchQuery, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Hero Carousel Manager Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Featured Hero Banners (${featuredItems.size} Active)",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Promoted titles appearing in the top auto-rotating homepage billboard",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (featuredItems.isEmpty()) {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = GlassSurfaceDark
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No hero banners currently featured. Toggle 'Featured' on titles below to pin them to the homepage billboard.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(featuredItems, key = { it.id }) { item ->
                    GlassCard(
                        modifier = Modifier
                            .width(260.dp)
                            .height(160.dp),
                        backgroundColor = GlassSurfaceDark
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = item.backdropUrl.ifEmpty { item.posterUrl },
                                contentDescription = item.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Transparent,
                                                MidnightBlack.copy(alpha = 0.5f),
                                                MidnightBlack.copy(alpha = 0.95f)
                                            )
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(PurpleCyanGradient)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(item.type, color = MidnightBlack, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }

                                    IconButton(
                                        onClick = { onToggleFeatured(item.id, item.isFeatured) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Remove banner",
                                            tint = CoralRed,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = item.title,
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${item.genre} • ★ ${item.rating}",
                                    color = NeonCyan,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Catalog Curation & Toggles Table
        Text(
            text = "Homepage Placement Toggles",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Toggle Hero Banner or Trending Rail positioning for any catalog title",
            color = TextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        GlassTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = "Filter catalog for placement...",
            leadingIcon = Icons.Default.Search,
            testTag = "admin_banner_search_input"
        )

        Spacer(modifier = Modifier.height(12.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            filteredContent.forEach { item ->
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = GlassSurfaceDark
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(width = 40.dp, height = 54.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(DeepIndigoBg)
                            ) {
                                AsyncImage(
                                    model = item.posterUrl,
                                    contentDescription = item.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = item.title,
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = "${item.type} • ${item.genre}",
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Featured Banner Toggle
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Hero Banner",
                                    color = if (item.isFeatured) NeonCyan else TextMuted,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Switch(
                                    checked = item.isFeatured,
                                    onCheckedChange = { onToggleFeatured(item.id, item.isFeatured) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = MidnightBlack,
                                        checkedTrackColor = NeonCyan
                                    ),
                                    modifier = Modifier.scale(0.8f)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Trending Toggle
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Trending",
                                    color = if (item.isTrending) VibrantPurple else TextMuted,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Switch(
                                    checked = item.isTrending,
                                    onCheckedChange = { onToggleTrending(item.id, item.isTrending) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = MidnightBlack,
                                        checkedTrackColor = VibrantPurple
                                    ),
                                    modifier = Modifier.scale(0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// -----------------------------------------------------------------------------------------
// TAB 7: System Settings & Platform Configuration
// -----------------------------------------------------------------------------------------
@Composable
fun AdminSettingsTab(
    currentUser: User?,
    stats: DashboardStats,
    onPurgeCache: () -> Unit
) {
    var adaptiveBitrateEnabled by remember { mutableStateOf(true) }
    var hdStreamingEnabled by remember { mutableStateOf(true) }
    var autoApproveNatokRequests by remember { mutableStateOf(false) }
    var maintenanceModeEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Admin Profile Info Card
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurfaceDark
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(PurpleCyanGradient),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = MidnightBlack,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = currentUser?.fullName ?: "Streamix Super Administrator",
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "@${currentUser?.username ?: "admin"} • Security Role: ADMIN",
                                color = NeonCyan,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(EmeraldGreen.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("AUTHENTICATED", color = EmeraldGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // OTT Video & Streaming Engine Settings
        Text(
            text = "Video CDN & Streaming Engine",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurfaceDark
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("1080p FHD & 4K HLS Adaptive Streams", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Dynamic multi-bitrate ladder for Bangladeshi broadband & 4G/5G", color = TextSecondary, fontSize = 10.sp)
                    }
                    Switch(
                        checked = adaptiveBitrateEnabled,
                        onCheckedChange = { adaptiveBitrateEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MidnightBlack, checkedTrackColor = NeonCyan)
                    )
                }

                HorizontalDivider(color = GlassCardBorder.copy(alpha = 0.3f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Mobile Low-Bandwidth Mode (480p/360p)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Optimized data-saver compression for cellular streaming", color = TextSecondary, fontSize = 10.sp)
                    }
                    Switch(
                        checked = hdStreamingEnabled,
                        onCheckedChange = { hdStreamingEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MidnightBlack, checkedTrackColor = NeonCyan)
                    )
                }

                HorizontalDivider(color = GlassCardBorder.copy(alpha = 0.3f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Edge Cache & Media CDN Purge", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Flush cached thumbnails, playlists, and manifest headers", color = TextSecondary, fontSize = 10.sp)
                    }
                    GlassButton(
                        text = "Purge Cache",
                        icon = Icons.Default.Refresh,
                        onClick = onPurgeCache
                    )
                }
            }
        }

        // Platform Operations & Maintenance
        Text(
            text = "Platform Ingestion & Operations",
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = GlassSurfaceDark
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Content Request Notifications", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Push subscriber requests immediately to CMS pending queue", color = TextSecondary, fontSize = 10.sp)
                    }
                    Switch(
                        checked = autoApproveNatokRequests,
                        onCheckedChange = { autoApproveNatokRequests = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MidnightBlack, checkedTrackColor = VibrantPurple)
                    )
                }

                HorizontalDivider(color = GlassCardBorder.copy(alpha = 0.3f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Maintenance Mode (Lock Platform)", color = CoralRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Shows maintenance screen to subscribers during scheduled ingest", color = TextSecondary, fontSize = 10.sp)
                    }
                    Switch(
                        checked = maintenanceModeEnabled,
                        onCheckedChange = { maintenanceModeEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MidnightBlack, checkedTrackColor = CoralRed)
                    )
                }
            }
        }

        // Operational Diagnostics
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            backgroundColor = DeepIndigoBg.copy(alpha = 0.7f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "System Diagnostics & Live Integrity",
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Database Engine: Room SQLite Encrypted • Status: OPERATIONAL\nTotal Content Assets: ${stats.totalVideos} entries\nTotal Recorded Views: ${stats.totalViews} streams\nActive User Base: ${stats.activeUsers} / ${stats.totalUsers} registered",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

// -----------------------------------------------------------------------------------------
// DIALOGS: Add/Edit Content, Feedback, Add Category
// -----------------------------------------------------------------------------------------
@Composable
fun AddEditContentDialog(
    initialItem: ContentItem?,
    categories: List<Category>,
    onDismiss: () -> Unit,
    onSave: (ContentItem, List<Episode>) -> Unit
) {
    var title by remember { mutableStateOf(initialItem?.title ?: "") }
    var type by remember { mutableStateOf(initialItem?.type ?: "NATOK") }
    var description by remember { mutableStateOf(initialItem?.description ?: "") }
    var genre by remember { mutableStateOf(initialItem?.genre ?: "Drama, Romance") }
    var releaseYear by remember { mutableStateOf(initialItem?.releaseYear?.toString() ?: "2024") }
    var durationMinutes by remember { mutableStateOf(initialItem?.durationMinutes?.toString() ?: "45") }
    var rating by remember { mutableStateOf(initialItem?.rating?.toString() ?: "4.8") }
    var posterUrl by remember { mutableStateOf(initialItem?.posterUrl ?: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=600&auto=format&fit=crop&q=80") }
    var backdropUrl by remember { mutableStateOf(initialItem?.backdropUrl ?: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&auto=format&fit=crop&q=80") }
    var videoUrl by remember { mutableStateOf(initialItem?.videoUrl ?: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4") }
    var castAndCrew by remember { mutableStateOf(initialItem?.castAndCrew ?: "Afran Nisho, Mehazabien Chowdhury") }
    var tags by remember { mutableStateOf(initialItem?.tags ?: "Bangla Natok, Romantic, Emotional") }
    var isFeatured by remember { mutableStateOf(initialItem?.isFeatured ?: false) }
    var isTrending by remember { mutableStateOf(initialItem?.isTrending ?: true) }
    var isPublished by remember { mutableStateOf(initialItem?.isPublished ?: true) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkNavyBg,
        title = {
            Text(
                text = if (initialItem == null) "Add New Content Title" else "Edit Content: ${initialItem.title}",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Title
                GlassTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = "Title",
                    placeholder = "e.g. Punorjonmo 4",
                    testTag = "admin_dialog_title_input"
                )

                // Type selector
                Text("Content Type", color = VibrantPurple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("NATOK", "MOVIE", "SERIES", "FILM").forEach { t ->
                        val isSelected = type == t
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .then(
                                    if (isSelected) Modifier.background(PurpleCyanGradient)
                                    else Modifier.background(DeepIndigoBg)
                                )
                                .clickable { type = t }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = t,
                                color = if (isSelected) MidnightBlack else TextSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Genre & Release Year
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassTextField(
                        value = genre,
                        onValueChange = { genre = it },
                        label = "Genre",
                        placeholder = "Thriller, Mystery",
                        modifier = Modifier.weight(1f)
                    )
                    GlassTextField(
                        value = releaseYear,
                        onValueChange = { releaseYear = it },
                        label = "Year",
                        placeholder = "2024",
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(0.6f)
                    )
                }

                // Duration & Rating
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassTextField(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it },
                        label = "Duration (min)",
                        placeholder = "45",
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    GlassTextField(
                        value = rating,
                        onValueChange = { rating = it },
                        label = "IMDb / Rating",
                        placeholder = "4.9",
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Description
                GlassTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = "Synopsis / Description",
                    placeholder = "Detailed plot synopsis...",
                    singleLine = false,
                    modifier = Modifier.height(80.dp)
                )

                // Poster & Backdrop
                GlassTextField(
                    value = posterUrl,
                    onValueChange = { posterUrl = it },
                    label = "Poster Image URL",
                    placeholder = "https://..."
                )
                GlassTextField(
                    value = backdropUrl,
                    onValueChange = { backdropUrl = it },
                    label = "Backdrop Banner URL",
                    placeholder = "https://..."
                )

                // Video URL
                GlassTextField(
                    value = videoUrl,
                    onValueChange = { videoUrl = it },
                    label = "Playback Video Stream URL (MP4 / HLS)",
                    placeholder = "https://..."
                )

                // Cast & Crew
                GlassTextField(
                    value = castAndCrew,
                    onValueChange = { castAndCrew = it },
                    label = "Cast & Director",
                    placeholder = "Afran Nisho, Vicky Zahed"
                )

                // Toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Featured in Hero Banner", color = TextPrimary, fontSize = 12.sp)
                    Switch(
                        checked = isFeatured,
                        onCheckedChange = { isFeatured = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MidnightBlack, checkedTrackColor = NeonCyan)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Publish to Public Catalog", color = TextPrimary, fontSize = 12.sp)
                    Switch(
                        checked = isPublished,
                        onCheckedChange = { isPublished = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MidnightBlack, checkedTrackColor = EmeraldGreen)
                    )
                }

                AnimatedVisibility(visible = errorMessage != null) {
                    errorMessage?.let {
                        Text(it, color = CoralRed, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            GlassButton(
                text = if (initialItem == null) "Create Title" else "Save Changes",
                onClick = {
                    if (title.isBlank()) {
                        errorMessage = "Title cannot be blank"
                        return@GlassButton
                    }
                    val contentId = initialItem?.id ?: "c_${UUID.randomUUID().toString().take(8)}"
                    val item = ContentItem(
                        id = contentId,
                        title = title.trim(),
                        type = type,
                        description = description.trim(),
                        genre = genre.trim(),
                        releaseYear = releaseYear.toIntOrNull() ?: 2024,
                        durationMinutes = durationMinutes.toIntOrNull() ?: 45,
                        rating = rating.toDoubleOrNull() ?: 4.8,
                        posterUrl = posterUrl.trim(),
                        backdropUrl = backdropUrl.trim(),
                        videoUrl = videoUrl.trim(),
                        castAndCrew = castAndCrew.trim(),
                        tags = tags.trim(),
                        isFeatured = isFeatured,
                        isTrending = isTrending,
                        isPublished = isPublished,
                        viewsCount = initialItem?.viewsCount ?: 0
                    )
                    onSave(item, emptyList())
                },
                testTag = "admin_dialog_save_btn"
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun AdminRequestFeedbackDialog(
    request: ContentRequest,
    actionType: String,
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var feedbackText by remember {
        mutableStateOf(
            when (actionType) {
                "APPROVED" -> "Approved! Content is currently being scheduled into the Streamix BD ingest pipeline."
                "COMPLETED" -> "Content has been added! Enjoy streaming on Streamix BD."
                "REJECTED" -> "Sorry, content licensing or master is currently unavailable in Bangladesh."
                else -> ""
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkNavyBg,
        title = {
            Text(
                text = "Update Request: ${request.title}",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column {
                Text(
                    text = "Status will become: $actionType",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                GlassTextField(
                    value = feedbackText,
                    onValueChange = { feedbackText = it },
                    label = "Admin Feedback for User",
                    placeholder = "Message to user...",
                    singleLine = false,
                    modifier = Modifier.height(90.dp)
                )
            }
        },
        confirmButton = {
            GlassButton(
                text = "Confirm & Notify",
                onClick = { onSubmit(feedbackText) }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun AddCategoryDialog(
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var slug by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkNavyBg,
        title = { Text("Add New Streamix Category", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        if (slug.isBlank() || slug == it.dropLast(1).lowercase().replace(" ", "-")) {
                            slug = it.lowercase().replace(" ", "-")
                        }
                    },
                    label = "Category Name",
                    placeholder = "e.g. Comedy Natoks"
                )
                GlassTextField(
                    value = slug,
                    onValueChange = { slug = it },
                    label = "URL Slug",
                    placeholder = "e.g. comedy-natoks"
                )
            }
        },
        confirmButton = {
            GlassButton(
                text = "Add Category",
                onClick = {
                    if (name.isNotBlank()) onSave(name, slug.ifBlank { name.lowercase().replace(" ", "-") })
                }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

// -----------------------------------------------------------------------------------------
// TAB: Admin Announcements Management
// -----------------------------------------------------------------------------------------
@Composable
fun AdminAnnouncementsTab(
    announcements: List<Announcement>,
    onAddNew: () -> Unit,
    onEdit: (Announcement) -> Unit,
    onDelete: (String) -> Unit,
    onToggleActive: (String, Boolean) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterStatus by remember { mutableStateOf("ALL") } // ALL, ACTIVE, INACTIVE
    var announcementToDelete by remember { mutableStateOf<Announcement?>(null) }

    val filteredAnnouncements = announcements.filter { item ->
        val matchesSearch = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.message.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (filterStatus) {
            "ACTIVE" -> item.isActive
            "INACTIVE" -> !item.isActive
            else -> true
        }
        matchesSearch && matchesFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 4.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Broadcast Announcements",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Publish notices & promotional alerts to all users' Home screen",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            GlassButton(
                text = "New Announcement",
                icon = Icons.Default.Campaign,
                onClick = onAddNew,
                testTag = "admin_add_announcement_btn"
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search and Filter Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = "Search announcements...",
                leadingIcon = Icons.Default.Search,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Status Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = filterStatus == "ALL",
                onClick = { filterStatus = "ALL" },
                label = { Text("All (${announcements.size})", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = VibrantPurple,
                    selectedLabelColor = Color.White,
                    containerColor = DarkNavyBg,
                    labelColor = TextSecondary
                )
            )
            FilterChip(
                selected = filterStatus == "ACTIVE",
                onClick = { filterStatus = "ACTIVE" },
                label = { Text("Active (${announcements.count { it.isActive }})", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldGreen,
                    selectedLabelColor = MidnightBlack,
                    containerColor = DarkNavyBg,
                    labelColor = TextSecondary
                )
            )
            FilterChip(
                selected = filterStatus == "INACTIVE",
                onClick = { filterStatus = "INACTIVE" },
                label = { Text("Inactive (${announcements.count { !it.isActive }})", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CoralRed.copy(alpha = 0.8f),
                    selectedLabelColor = Color.White,
                    containerColor = DarkNavyBg,
                    labelColor = TextSecondary
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (filteredAnnouncements.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "No matching announcements" else "No announcements published yet",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    GlassButton(
                        text = "Create Announcement",
                        icon = Icons.Default.Add,
                        onClick = onAddNew
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredAnnouncements, key = { it.id }) { ann ->
                    AnnouncementAdminCard(
                        announcement = ann,
                        onEdit = { onEdit(ann) },
                        onDelete = { announcementToDelete = ann },
                        onToggleActive = { onToggleActive(ann.id, ann.isActive) }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (announcementToDelete != null) {
        val target = announcementToDelete!!
        AlertDialog(
            onDismissRequest = { announcementToDelete = null },
            containerColor = DarkNavyBg,
            title = {
                Text(
                    text = "Delete Announcement?",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to permanently delete \"${target.title}\"? This action will remove it from all users' Home screens.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                GlassButton(
                    text = "Delete",
                    onClick = {
                        onDelete(target.id)
                        announcementToDelete = null
                    },
                    modifier = Modifier.testTag("confirm_delete_announcement_btn")
                )
            },
            dismissButton = {
                TextButton(onClick = { announcementToDelete = null }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun AnnouncementAdminCard(
    announcement: Announcement,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggleActive: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH) }
    val formattedDate = remember(announcement.createdAt) {
        dateFormat.format(Date(announcement.createdAt))
    }

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = GlassSurfaceDark,
        borderColor = if (announcement.isActive) EmeraldGreen.copy(alpha = 0.4f) else GlassCardBorder
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Status & Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (announcement.isActive) EmeraldGreen.copy(alpha = 0.2f) else DarkNavyBg)
                            .border(
                                1.dp,
                                if (announcement.isActive) EmeraldGreen else TextMuted,
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (announcement.isActive) "● Active on Home Screen" else "○ Inactive / Hidden",
                            color = if (announcement.isActive) EmeraldGreen else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (announcement.imageUrl.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonCyan.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "🖼️ With Photo",
                                color = NeonCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(VibrantPurple.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "📝 Text Only",
                                color = VibrantPurple,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Text(
                    text = formattedDate,
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Photo Preview if provided
            if (announcement.imageUrl.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkNavyBg)
                ) {
                    AsyncImage(
                        model = announcement.imageUrl,
                        contentDescription = announcement.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Title & Message
            Text(
                text = announcement.title,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = announcement.message,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "By ${announcement.authorName}",
                color = NeonCyan,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 10.dp),
                color = GlassCardBorder
            )

            // Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Active Switch
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onToggleActive() }
                ) {
                    Switch(
                        checked = announcement.isActive,
                        onCheckedChange = { onToggleActive() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MidnightBlack,
                            checkedTrackColor = EmeraldGreen,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = DarkNavyBg
                        ),
                        modifier = Modifier.scale(0.8f)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (announcement.isActive) "Active" else "Inactive",
                        color = if (announcement.isActive) EmeraldGreen else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Edit & Delete buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Announcement",
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Announcement",
                            tint = CoralRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// Add / Edit Announcement Dialog with Photo Support & Live Preview
// -----------------------------------------------------------------------------------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditAnnouncementDialog(
    initialAnnouncement: Announcement?,
    onDismiss: () -> Unit,
    onSave: (Announcement) -> Unit
) {
    var title by remember { mutableStateOf(initialAnnouncement?.title ?: "") }
    var message by remember { mutableStateOf(initialAnnouncement?.message ?: "") }
    var imageUrl by remember { mutableStateOf(initialAnnouncement?.imageUrl ?: "") }
    var isActive by remember { mutableStateOf(initialAnnouncement?.isActive ?: true) }
    var author by remember { mutableStateOf(initialAnnouncement?.authorName ?: "Streamix Admin") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Quick Image Suggestions for fast testing and visual flair
    val photoSuggestions = listOf(
        "🎉 Eid Premiere" to "https://images.unsplash.com/photo-1578836537282-3171d77f8632?w=800&q=80",
        "🎬 Blockbuster Cinema" to "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&q=80",
        "⚡ Special Offer" to "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=800&q=80",
        "🛠️ System Update" to "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkNavyBg,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (initialAnnouncement != null) Icons.Default.Edit else Icons.Default.Campaign,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (initialAnnouncement != null) "Edit Announcement" else "New Broadcast Announcement",
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (errorMessage != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CoralRed.copy(alpha = 0.15f))
                            .border(1.dp, CoralRed, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = errorMessage!!,
                            color = CoralRed,
                            fontSize = 12.sp
                        )
                    }
                }

                // Title Input
                GlassTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        errorMessage = null
                    },
                    label = "Announcement Title *",
                    placeholder = "e.g. 📢 Eid Ul Fitr Exclusive Dramas Streaming Now!",
                    leadingIcon = Icons.Default.Campaign,
                    modifier = Modifier.testTag("announcement_title_input")
                )

                // Message / Description Input
                GlassTextField(
                    value = message,
                    onValueChange = {
                        message = it
                        errorMessage = null
                    },
                    label = "Announcement Message / Details *",
                    placeholder = "Write the announcement message for users...",
                    singleLine = false,
                    modifier = Modifier.testTag("announcement_message_input")
                )

                // Photo URL Input (Optional)
                GlassTextField(
                    value = imageUrl,
                    onValueChange = { imageUrl = it },
                    label = "Photo / Banner URL (Optional)",
                    placeholder = "https://... (or select a quick preset below)",
                    leadingIcon = Icons.Default.AddPhotoAlternate,
                    trailingIcon = {
                        if (imageUrl.isNotBlank()) {
                            IconButton(onClick = { imageUrl = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear Photo",
                                    tint = CoralRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    modifier = Modifier.testTag("announcement_image_input")
                )

                // Quick photo preset buttons
                Column {
                    Text(
                        text = "Quick Photo Presets (Optional):",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        photoSuggestions.forEach { (label, url) ->
                            val isSelected = imageUrl == url
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSelected) VibrantPurple else DeepIndigoBg)
                                    .border(
                                        1.dp,
                                        if (isSelected) NeonCyan else GlassCardBorder,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        imageUrl = if (isSelected) "" else url
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.White else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                // Live Photo Preview Card
                Text(
                    text = "Photo Preview:",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )

                if (imageUrl.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MidnightBlack)
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    ) {
                        AsyncImage(
                            model = imageUrl,
                            contentDescription = "Announcement Photo Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Clear Button overlay
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(6.dp)
                                .clip(CircleShape)
                                .background(MidnightBlack.copy(alpha = 0.7f))
                                .clickable { imageUrl = "" }
                                .padding(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove photo",
                                tint = CoralRed,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(DeepIndigoBg)
                            .border(1.dp, GlassCardBorder, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Photo is optional — Announcement will display as a clean text card",
                                color = TextMuted,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Author Input
                GlassTextField(
                    value = author,
                    onValueChange = { author = it },
                    label = "Author / Team Name",
                    placeholder = "e.g. Streamix Admin Team"
                )

                // Active / Inactive Toggle Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DeepIndigoBg)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Publish on Home Screen",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isActive) "Visible to all users immediately" else "Saved as inactive / draft",
                            color = if (isActive) EmeraldGreen else TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MidnightBlack,
                            checkedTrackColor = EmeraldGreen,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = DarkNavyBg
                        )
                    )
                }
            }
        },
        confirmButton = {
            GlassButton(
                text = if (initialAnnouncement != null) "Update & Save" else "Publish Announcement",
                icon = Icons.Default.Check,
                onClick = {
                    if (title.isBlank()) {
                        errorMessage = "Please enter an announcement title"
                        return@GlassButton
                    }
                    if (message.isBlank()) {
                        errorMessage = "Please enter announcement message details"
                        return@GlassButton
                    }

                    val announcementToSave = Announcement(
                        id = initialAnnouncement?.id ?: "ann_${UUID.randomUUID().toString().take(8)}",
                        title = title.trim(),
                        message = message.trim(),
                        imageUrl = imageUrl.trim(),
                        createdAt = initialAnnouncement?.createdAt ?: System.currentTimeMillis(),
                        isActive = isActive,
                        authorName = author.trim().ifBlank { "Streamix Admin" }
                    )
                    onSave(announcementToSave)
                },
                modifier = Modifier.testTag("save_announcement_btn")
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
