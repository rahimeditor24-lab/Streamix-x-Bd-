package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.ui.theme.*

/**
 * Custom Chevron Shape for the "BD" Futuristic Tag in Style 4
 */
val ChevronBadgeShape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    val corner = 8f
    val chevronIndent = h * 0.35f

    moveTo(corner, 0f)
    lineTo(w - chevronIndent, 0f)
    lineTo(w, h / 2f)
    lineTo(w - chevronIndent, h)
    lineTo(corner, h)
    lineTo(0f, h / 2f)
    close()
}

/**
 * Top Header for Streamix BD - Styled exactly according to Reference "STYLE 4"
 *
 * Features:
 * 1. Dark Neon Glass Outer Container with top Purple & bottom Cyan glowing border + subtle ambient shadow.
 * 2. STYLE 4 Logo Play Box (Left): Rounded square dark glass badge with dual neon glowing border (Purple top, Cyan bottom) and crisp white play arrow.
 * 3. STYLE 4 Futuristic Typography: S T R E A M I X with purple-to-cyan sci-fi gradient, stylized "E", wide futuristic tracking.
 * 4. STYLE 4 "BD" Futuristic Chevron Badge with glowing neon cyan border.
 * 5. Compact Admin Panel Button (No 👑 icon, sleek & minimal).
 * 6. Prominent Search Button (Right): 20-25% larger (52dp), circular dual-ring glass style with cyan/purple neon glow.
 * 7. Fully responsive and preserving all existing interactions.
 */
@Composable
fun StreamixTopHeader(
    currentUser: User?,
    onSearchClick: () -> Unit,
    onAdminClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            // Main Outer Glass Frame with red-black glassmorphism & soft red glow
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 1200.dp)
                    .align(Alignment.Center)
                    .shadow(
                        elevation = 14.dp,
                        shape = RoundedCornerShape(20.dp),
                        spotColor = BrightRedAccent.copy(alpha = 0.45f),
                        ambientColor = CrimsonRed.copy(alpha = 0.25f)
                    )
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xF5171114),
                                Color(0xF80B0B0E),
                                Color(0xF5131015)
                            )
                        )
                    )
                    .border(
                        width = 1.2.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                CrimsonRed.copy(alpha = 0.85f),
                                BrightRedAccent.copy(alpha = 0.90f),
                                Color.White.copy(alpha = 0.25f),
                                DeepCrimson.copy(alpha = 0.60f)
                            )
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Subtle Red Tech Dot Matrix Grid Overlay on the right
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth(0.35f)
                        .matchParentSize()
                        .align(Alignment.CenterEnd)
                ) {
                    val dotRadius = 1.2.dp.toPx()
                    val spacing = 10.dp.toPx()
                    val rows = (size.height / spacing).toInt()
                    val cols = (size.width / spacing).toInt()

                    for (r in 0..rows) {
                        for (c in 0..cols) {
                            val alpha = ((c.toFloat() / cols.toFloat()) * 0.18f).coerceIn(0f, 0.22f)
                            drawCircle(
                                color = BrightRedAccent.copy(alpha = alpha),
                                radius = dotRadius,
                                center = Offset(c * spacing, r * spacing)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left side: Logo Box + Futuristic "S T R E A M I X [ BD > ]" Red/Black Branding
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .testTag("app_brand_header")
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { }
                    ) {
                        // Logo Badge (Red/Black Glass with Crimson border)
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .shadow(
                                    elevation = 8.dp,
                                    shape = RoundedCornerShape(12.dp),
                                    spotColor = BrightRedAccent.copy(alpha = 0.6f),
                                    ambientColor = CrimsonRed.copy(alpha = 0.4f)
                                )
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            DeepCrimson,
                                            Color(0xFF140D10)
                                        )
                                    )
                                )
                                .border(
                                    width = 1.8.dp,
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            BrightRedAccent,
                                            CrimsonRed
                                        )
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = "Streamix BD",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // Futuristic Red/White Typography: S T R E A M I X + [ BD ]
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(1.dp)
                        ) {
                            // "S T" in Crimson Red
                            Text(
                                text = "ST",
                                color = CrimsonRed,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.5.sp
                            )

                            Text(
                                text = "R",
                                color = BrightRedAccent,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.5.sp
                            )

                            // Stylized Futuristic "E" (Horizontal Bars in Bright Red)
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .size(width = 11.dp, height = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    verticalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxHeight(0.85f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(2.dp)
                                            .clip(RoundedCornerShape(1.dp))
                                            .background(BrightRedAccent)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(0.75f)
                                            .height(2.dp)
                                            .clip(RoundedCornerShape(1.dp))
                                            .background(BrightRedAccent)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(2.dp)
                                            .clip(RoundedCornerShape(1.dp))
                                            .background(BrightRedAccent)
                                    )
                                }
                            }

                            // "A M I X" in Crisp White
                            Text(
                                text = "AMIX",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.5.sp
                            )

                            Spacer(modifier = Modifier.width(7.dp))

                            // Futuristic "BD" Red Glass Tech Pill Badge
                            Box(
                                modifier = Modifier
                                    .height(22.dp)
                                    .shadow(
                                        elevation = 4.dp,
                                        shape = RoundedCornerShape(6.dp),
                                        spotColor = BrightRedAccent.copy(alpha = 0.5f)
                                    )
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                BrightRedAccent.copy(alpha = 0.25f),
                                                Color(0x331C1318)
                                            )
                                        )
                                    )
                                    .border(
                                        width = 1.2.dp,
                                        brush = Brush.horizontalGradient(
                                            colors = listOf(
                                                BrightRedAccent,
                                                CrimsonRed.copy(alpha = 0.6f),
                                                BrightRedAccent
                                            )
                                        ),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text(
                                        text = "BD",
                                        color = BrightRedAccent,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 0.5.sp
                                    )
                                    // Futuristic Chevron Bracket ">"
                                    Text(
                                        text = "❯",
                                        color = BrightRedAccent.copy(alpha = 0.8f),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Right side: Admin Panel Button + Red-Glowing Circular Search Button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Admin Panel Button (Sleek red-tinted glass)
                        Box(
                            modifier = Modifier
                                .height(26.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(GlassSurfaceDark.copy(alpha = 0.7f))
                                .border(
                                    width = 1.dp,
                                    color = GlassCardBorderRed.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(13.dp)
                                )
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = onAdminClick
                                )
                                .padding(horizontal = 9.dp)
                                .testTag("admin_panel_entry_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Admin",
                                color = TextSecondary,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.3.sp
                            )
                        }

                        // Circular Concentric Red Search Button with Soft Red Glow
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .shadow(
                                    elevation = 14.dp,
                                    shape = CircleShape,
                                    spotColor = BrightRedAccent.copy(alpha = 0.65f),
                                    ambientColor = CrimsonRed.copy(alpha = 0.40f)
                                )
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            DeepCrimson.copy(alpha = 0.5f),
                                            Color(0xFF0F0C0F)
                                        )
                                    )
                                )
                                .border(
                                    width = 2.dp,
                                    brush = Brush.sweepGradient(
                                        listOf(
                                            BrightRedAccent,
                                            CrimsonRed,
                                            DeepCrimson,
                                            BrightRedAccent
                                        )
                                    ),
                                    shape = CircleShape
                                )
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = onSearchClick
                                )
                                .testTag("top_search_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            // Inner subtle concentric ring
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(0x33FF1744))
                                    .border(0.8.dp, BrightRedAccent.copy(alpha = 0.45f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = "Search movies, natok, films, series",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
