package com.example.data.repository

import android.content.Context
import com.example.data.local.StreamixDatabase
import com.example.data.model.Announcement
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.ContentRequest
import com.example.data.model.DashboardStats
import com.example.data.model.DownloadItem
import com.example.data.model.DownloadStatus
import com.example.data.model.Episode
import com.example.data.model.SavedItem
import com.example.data.model.User
import com.example.data.model.WatchHistory
import com.example.data.remote.FirestoreSyncService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class StreamixRepository(
    private val context: Context,
    private val database: StreamixDatabase = StreamixDatabase.getInstance(context)
) {
    private val userDao = database.userDao()
    private val contentDao = database.contentDao()
    private val episodeDao = database.episodeDao()
    private val categoryDao = database.categoryDao()
    private val contentRequestDao = database.contentRequestDao()
    private val savedItemDao = database.savedItemDao()
    private val watchHistoryDao = database.watchHistoryDao()
    private val downloadDao = database.downloadDao()
    private val announcementDao = database.announcementDao()

    private val repositoryScope = CoroutineScope(Dispatchers.IO + Job())

    // Online Firestore Real-Time Synchronizer
    val firestoreSync = FirestoreSyncService(
        contentDao = contentDao,
        episodeDao = episodeDao,
        categoryDao = categoryDao,
        contentRequestDao = contentRequestDao,
        announcementDao = announcementDao,
        scope = repositoryScope
    )

    val isSyncing: StateFlow<Boolean> = firestoreSync.isSyncing
    val isFirebaseAvailable: StateFlow<Boolean> = firestoreSync.isFirebaseAvailable

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _isCasting = MutableStateFlow(false)
    val isCasting: StateFlow<Boolean> = _isCasting.asStateFlow()

    private val _connectedCastDevice = MutableStateFlow<String?>(null)
    val connectedCastDevice: StateFlow<String?> = _connectedCastDevice.asStateFlow()

    // Active download jobs in memory
    private val downloadJobs = ConcurrentHashMap<String, Job>()

    init {
        repositoryScope.launch {
            seedDatabaseIfEmpty()
            // Start online real-time sync with Firestore (falls back gracefully to Room if offline)
            firestoreSync.startSync()
        }
    }

    private suspend fun seedDatabaseIfEmpty() {
        withContext(Dispatchers.IO) {
            val userCount = userDao.getTotalUsersCount()
            if (userCount == 0) {
                userDao.insertUser(SeedData.defaultAdmin)
                userDao.insertUser(SeedData.defaultDemoUser)
            } else {
                // If a new STREAMIX_ADMIN_PASSWORD environment secret is provided, sync admin password hash securely
                val configuredPassword = SeedData.getAdminConfiguredPassword()
                if (configuredPassword != null) {
                    val adminUser = userDao.getUserByUsernameOrEmail("admin")
                    if (adminUser != null && adminUser.role.equals("ADMIN", ignoreCase = true)) {
                        val newHash = SeedData.hashPassword(configuredPassword)
                        if (adminUser.passwordHash != newHash) {
                            userDao.updateUser(adminUser.copy(passwordHash = newHash))
                        }
                    }
                }
            }

            val categoryCount = categoryDao.getCategoryCount()
            if (categoryCount == 0) {
                categoryDao.insertAllCategories(SeedData.categories)
            }

            val contentCount = contentDao.getTotalContentCount()
            if (contentCount == 0) {
                contentDao.insertAllContent(SeedData.initialContent)
            }

            val episodeCount = episodeDao.getTotalEpisodesCount()
            if (episodeCount == 0) {
                episodeDao.insertAllEpisodes(SeedData.episodes)
            }

            val pendingRequests = contentRequestDao.getPendingRequestsCount()
            if (pendingRequests == 0) {
                SeedData.sampleRequests.forEach { contentRequestDao.insertRequest(it) }
            }

            val announcementCount = announcementDao.getTotalAnnouncementsCount()
            if (announcementCount == 0) {
                announcementDao.insertAllAnnouncements(SeedData.sampleAnnouncements)
            }

            if (userCount == 0) {
                // Initial watch history
                watchHistoryDao.saveWatchHistory(
                    WatchHistory(
                        userId = SeedData.defaultDemoUser.id,
                        contentId = "c_01",
                        episodeId = "",
                        watchedSeconds = 3400L,
                        totalDurationSeconds = 8520L,
                        lastWatchedAt = System.currentTimeMillis()
                    )
                )

                // Initial saved item
                savedItemDao.insertSavedItem(
                    SavedItem(
                        userId = SeedData.defaultDemoUser.id,
                        contentId = "c_01"
                    )
                )
                savedItemDao.insertSavedItem(
                    SavedItem(
                        userId = SeedData.defaultDemoUser.id,
                        contentId = "c_02"
                    )
                )
            }
        }
    }

    // -------------------------------------------------------------
    // Authentication
    // -------------------------------------------------------------
    suspend fun login(usernameOrEmail: String, password: String): Result<User> {
        return withContext(Dispatchers.IO) {
            val cleanInput = usernameOrEmail.trim().lowercase()
            if (cleanInput.isBlank() || password.isBlank()) {
                return@withContext Result.failure(Exception("Please enter your username and password"))
            }

            val user = userDao.getUserByUsernameOrEmail(cleanInput)
                ?: return@withContext Result.failure(Exception("User not found with provided username or email"))

            if (user.status.equals("SUSPENDED", ignoreCase = true)) {
                return@withContext Result.failure(Exception("This account is currently suspended. Please contact support."))
            }

            val inputHash = SeedData.hashPassword(password)
            if (user.passwordHash != inputHash) {
                return@withContext Result.failure(Exception("Invalid password. Please try again."))
            }

            _currentUser.value = user
            Result.success(user)
        }
    }

    suspend fun adminLogin(usernameOrEmail: String, password: String): Result<User> {
        return withContext(Dispatchers.IO) {
            val cleanInput = usernameOrEmail.trim().lowercase()
            if (cleanInput.isBlank() || password.isBlank()) {
                return@withContext Result.failure(Exception("Invalid admin credentials"))
            }

            val user = userDao.getUserByUsernameOrEmail(cleanInput)
                ?: return@withContext Result.failure(Exception("Invalid admin credentials"))

            if (!user.role.equals("ADMIN", ignoreCase = true)) {
                return@withContext Result.failure(Exception("Invalid admin credentials"))
            }

            if (user.status.equals("SUSPENDED", ignoreCase = true)) {
                return@withContext Result.failure(Exception("Admin account is suspended"))
            }

            val configuredPassword = SeedData.getAdminConfiguredPassword()
            val inputHash = SeedData.hashPassword(password)

            val isValid = if (configuredPassword != null) {
                password == configuredPassword || user.passwordHash == inputHash || user.passwordHash == SeedData.hashPassword(configuredPassword)
            } else {
                user.passwordHash == inputHash
            }

            if (!isValid) {
                return@withContext Result.failure(Exception("Invalid admin credentials"))
            }

            if (user.passwordHash != inputHash) {
                userDao.updateUser(user.copy(passwordHash = inputHash))
            }

            _currentUser.value = user
            Result.success(user)
        }
    }

    suspend fun createInitialAdmin(
        username: String,
        email: String,
        password: String,
        fullName: String = "Streamix Administrator"
    ): Result<User> {
        return withContext(Dispatchers.IO) {
            val cleanUsername = username.trim().lowercase()
            val cleanEmail = email.trim().lowercase()

            if (cleanUsername.length < 3) {
                return@withContext Result.failure(Exception("Admin username must be at least 3 characters"))
            }
            if (!cleanEmail.contains("@") || !cleanEmail.contains(".")) {
                return@withContext Result.failure(Exception("Please enter a valid email address"))
            }
            if (password.length < 6) {
                return@withContext Result.failure(Exception("Admin password must be at least 6 characters"))
            }

            val existing = userDao.getUserByUsernameOrEmail(cleanUsername)
            if (existing != null) {
                if (existing.role.equals("ADMIN", ignoreCase = true)) {
                    val updatedAdmin = existing.copy(
                        passwordHash = SeedData.hashPassword(password),
                        fullName = fullName.ifBlank { existing.fullName }
                    )
                    userDao.updateUser(updatedAdmin)
                    _currentUser.value = updatedAdmin
                    return@withContext Result.success(updatedAdmin)
                } else {
                    val updatedAdmin = existing.copy(
                        role = "ADMIN",
                        passwordHash = SeedData.hashPassword(password),
                        fullName = fullName.ifBlank { existing.fullName }
                    )
                    userDao.updateUser(updatedAdmin)
                    _currentUser.value = updatedAdmin
                    return@withContext Result.success(updatedAdmin)
                }
            }

            val newAdmin = User(
                id = UUID.randomUUID().toString(),
                username = cleanUsername,
                email = cleanEmail,
                passwordHash = SeedData.hashPassword(password),
                fullName = fullName.ifBlank { "Streamix Administrator" },
                role = "ADMIN",
                status = "ACTIVE",
                avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80"
            )
            userDao.insertUser(newAdmin)
            _currentUser.value = newAdmin
            Result.success(newAdmin)
        }
    }

    suspend fun getAdminCount(): Int {
        return withContext(Dispatchers.IO) {
            userDao.getAdminCount()
        }
    }

    fun observeAdminCount(): Flow<Int> = userDao.observeAdminCount()

    suspend fun signUp(username: String, email: String, password: String, fullName: String): Result<User> {
        return withContext(Dispatchers.IO) {
            val cleanUsername = username.trim().lowercase()
            val cleanEmail = email.trim().lowercase()

            if (cleanUsername.length < 3) {
                return@withContext Result.failure(Exception("Username must be at least 3 characters long"))
            }
            if (!cleanEmail.contains("@") || !cleanEmail.contains(".")) {
                return@withContext Result.failure(Exception("Please enter a valid email address"))
            }
            if (password.length < 6) {
                return@withContext Result.failure(Exception("Password must be at least 6 characters"))
            }

            val existing = userDao.getUserByUsernameOrEmail(cleanUsername)
            if (existing != null) {
                return@withContext Result.failure(Exception("Username or email is already registered"))
            }

            val newUser = User(
                id = UUID.randomUUID().toString(),
                username = cleanUsername,
                email = cleanEmail,
                passwordHash = SeedData.hashPassword(password),
                fullName = fullName.trim(),
                role = "USER",
                status = "ACTIVE",
                avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80"
            )
            userDao.insertUser(newUser)
            _currentUser.value = newUser
            Result.success(newUser)
        }
    }

    suspend fun resetPassword(email: String, newPassword: String): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            val user = userDao.getUserByUsernameOrEmail(email.trim().lowercase())
                ?: return@withContext Result.failure(Exception("No account registered with this email"))

            if (user.role.equals("ADMIN", ignoreCase = true)) {
                return@withContext Result.failure(Exception("Administrator passwords cannot be reset via public recovery. Please use internal administrator credentials."))
            }

            val updatedUser = user.copy(passwordHash = SeedData.hashPassword(newPassword))
            userDao.updateUser(updatedUser)
            Result.success(true)
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    fun setUser(user: User) {
        _currentUser.value = user
    }

    // -------------------------------------------------------------
    // Content Feeds & Observation
    // -------------------------------------------------------------
    fun getAllPublishedContent(): Flow<List<ContentItem>> = contentDao.getAllPublishedContent()
    fun getFeaturedContent(): Flow<List<ContentItem>> = contentDao.getFeaturedContent()
    fun getTrendingContent(): Flow<List<ContentItem>> = contentDao.getTrendingContent()
    fun getPopularContent(): Flow<List<ContentItem>> = contentDao.getPopularContent()
    fun getContentByType(type: String): Flow<List<ContentItem>> = contentDao.getContentByType(type)
    fun getCategories(): Flow<List<Category>> = categoryDao.getAllCategories()
    fun searchContent(query: String): Flow<List<ContentItem>> = contentDao.searchContent(query)

    suspend fun getContentById(id: String): ContentItem? = contentDao.getContentById(id)
    fun observeContentById(id: String): Flow<ContentItem?> = contentDao.observeContentById(id)
    fun getEpisodesForContent(contentId: String): Flow<List<Episode>> = episodeDao.getEpisodesForContent(contentId)

    suspend fun incrementViews(id: String) = contentDao.incrementViews(id)

    // -------------------------------------------------------------
    // Saved / My List
    // -------------------------------------------------------------
    fun isContentSaved(contentId: String): Flow<Boolean> {
        val userId = _currentUser.value?.id ?: "guest"
        return savedItemDao.isSaved(userId, contentId)
    }

    suspend fun toggleSaveContent(contentId: String) {
        val userId = _currentUser.value?.id ?: "guest"
        val isSaved = savedItemDao.isSaved(userId, contentId).firstOrNull() ?: false
        if (isSaved) {
            savedItemDao.removeSavedItem(userId, contentId)
        } else {
            savedItemDao.insertSavedItem(SavedItem(userId = userId, contentId = contentId))
        }
    }

    fun getSavedContentList(): Flow<List<ContentItem>> {
        val userId = _currentUser.value?.id ?: "guest"
        return combine(
            savedItemDao.getSavedItemsForUser(userId),
            contentDao.getAllPublishedContent()
        ) { savedItems, allContent ->
            val savedIds = savedItems.map { it.contentId }.toSet()
            allContent.filter { it.id in savedIds }
        }
    }

    // -------------------------------------------------------------
    // Watch History & Continue Watching
    // -------------------------------------------------------------
    fun getContinueWatchingList(): Flow<List<Pair<ContentItem, WatchHistory>>> {
        val userId = _currentUser.value?.id ?: "guest"
        return combine(
            watchHistoryDao.getWatchHistoryForUser(userId),
            contentDao.getAllPublishedContent()
        ) { historyList, allContent ->
            val contentMap = allContent.associateBy { it.id }
            historyList.mapNotNull { history ->
                val item = contentMap[history.contentId]
                if (item != null && history.watchedSeconds > 10 && !history.completed) {
                    Pair(item, history)
                } else {
                    null
                }
            }
        }
    }

    suspend fun saveWatchProgress(contentId: String, episodeId: String, watchedSeconds: Long, totalDurationSeconds: Long) {
        val userId = _currentUser.value?.id ?: "guest"
        val completed = totalDurationSeconds > 0 && watchedSeconds >= (totalDurationSeconds * 0.92f)
        val history = WatchHistory(
            userId = userId,
            contentId = contentId,
            episodeId = episodeId,
            watchedSeconds = watchedSeconds,
            totalDurationSeconds = totalDurationSeconds,
            lastWatchedAt = System.currentTimeMillis(),
            completed = completed
        )
        watchHistoryDao.saveWatchHistory(history)
    }

    // -------------------------------------------------------------
    // Content Requests
    // -------------------------------------------------------------
    suspend fun submitContentRequest(title: String, type: String, description: String): Result<ContentRequest> {
        return withContext(Dispatchers.IO) {
            val user = _currentUser.value ?: return@withContext Result.failure(Exception("Please log in to submit a request"))
            if (title.isBlank()) {
                return@withContext Result.failure(Exception("Title cannot be empty"))
            }

            val request = ContentRequest(
                id = UUID.randomUUID().toString(),
                title = title.trim(),
                contentType = type,
                requestedByUserId = user.id,
                requestedByUsername = user.username,
                description = description.trim(),
                status = "PENDING",
                submittedAt = System.currentTimeMillis(),
                adminFeedback = ""
            )
            firestoreSync.submitContentRequest(request)
            Result.success(request)
        }
    }

    fun getUserRequests(): Flow<List<ContentRequest>> {
        val userId = _currentUser.value?.id ?: "guest"
        return contentRequestDao.getRequestsByUser(userId)
    }

    fun getAllRequestsAdmin(): Flow<List<ContentRequest>> = contentRequestDao.getAllRequests()

    suspend fun updateRequestStatus(requestId: String, status: String, adminFeedback: String) {
        requireAdminRole()
        firestoreSync.updateRequestStatus(requestId, status, adminFeedback)
    }

    suspend fun deleteRequest(requestId: String) {
        requireAdminRole()
        firestoreSync.deleteRequest(requestId)
    }

    // -------------------------------------------------------------
    // Offline Downloads (Protected In-App Storage)
    // -------------------------------------------------------------
    fun getDownloads(): Flow<List<DownloadItem>> {
        val userId = _currentUser.value?.id ?: "guest"
        return downloadDao.getDownloadsForUser(userId)
    }

    suspend fun startDownload(
        content: ContentItem,
        episode: Episode? = null,
        quality: String = "1080p Full HD"
    ): Result<DownloadItem> {
        return withContext(Dispatchers.IO) {
            val userId = _currentUser.value?.id ?: "guest"
            val downloadId = "dl_${UUID.randomUUID().toString().take(8)}"
            val downloadDir = File(context.filesDir, "streamix_protected_vault").apply { mkdirs() }
            val sanitizedTitle = content.title.replace(Regex("[^a-zA-Z0-9]"), "_")
            val targetFile = File(downloadDir, "${downloadId}_${sanitizedTitle}.stmx")

            val estSizeMb = when (quality) {
                "4K Ultra HD" -> 1450.0
                "1080p Full HD" -> 680.0
                "720p HD" -> 380.0
                else -> 190.0
            }

            val downloadItem = DownloadItem(
                id = downloadId,
                userId = userId,
                contentId = content.id,
                episodeId = episode?.id ?: "",
                title = if (episode != null) "${content.title} - ${episode.title}" else content.title,
                contentType = content.type,
                filePath = targetFile.absolutePath,
                fileSizeMb = estSizeMb,
                progress = 0.05f,
                status = DownloadStatus.DOWNLOADING.name,
                quality = quality,
                thumbnailUrl = episode?.thumbnailUrl.takeIf { !it.isNullOrBlank() } ?: content.posterUrl,
                downloadedAt = System.currentTimeMillis()
            )

            downloadDao.insertDownload(downloadItem)
            launchDownloadSimulation(downloadItem, targetFile)

            Result.success(downloadItem)
        }
    }

    private fun launchDownloadSimulation(item: DownloadItem, targetFile: File) {
        val job = repositoryScope.launch {
            try {
                // Write protected file header
                FileOutputStream(targetFile).use { fos ->
                    fos.write("STREAMIX_VAULT_PROTECTED_V10".toByteArray())
                }

                var currentProgress = item.progress
                while (currentProgress < 1.0f) {
                    delay(500)
                    currentProgress += 0.08f
                    if (currentProgress > 1.0f) currentProgress = 1.0f

                    downloadDao.updateProgress(
                        downloadId = item.id,
                        progress = currentProgress,
                        status = if (currentProgress >= 1.0f) DownloadStatus.COMPLETED.name else DownloadStatus.DOWNLOADING.name
                    )
                }
            } catch (e: Exception) {
                downloadDao.updateProgress(
                    downloadId = item.id,
                    progress = item.progress,
                    status = DownloadStatus.FAILED.name
                )
            } finally {
                downloadJobs.remove(item.id)
            }
        }
        downloadJobs[item.id] = job
    }

    suspend fun pauseDownload(downloadId: String) {
        downloadJobs[downloadId]?.cancel()
        downloadJobs.remove(downloadId)
        val dl = downloadDao.getDownloadById(downloadId)
        if (dl != null) {
            downloadDao.updateProgress(downloadId, dl.progress, DownloadStatus.PAUSED.name)
        }
    }

    suspend fun resumeDownload(downloadId: String) {
        val dl = downloadDao.getDownloadById(downloadId) ?: return
        val targetFile = File(dl.filePath)
        downloadDao.updateProgress(downloadId, dl.progress, DownloadStatus.DOWNLOADING.name)
        launchDownloadSimulation(dl, targetFile)
    }

    suspend fun cancelDownload(downloadId: String) {
        downloadJobs[downloadId]?.cancel()
        downloadJobs.remove(downloadId)
        val dl = downloadDao.getDownloadById(downloadId)
        if (dl != null) {
            File(dl.filePath).delete()
            downloadDao.deleteDownload(downloadId)
        }
    }

    suspend fun deleteDownload(downloadId: String) {
        cancelDownload(downloadId)
    }

    // -------------------------------------------------------------
    // Smart TV / Casting Support
    // -------------------------------------------------------------
    fun connectCast(deviceName: String) {
        _isCasting.value = true
        _connectedCastDevice.value = deviceName
    }

    fun disconnectCast() {
        _isCasting.value = false
        _connectedCastDevice.value = null
    }

    // -------------------------------------------------------------
    // Security & Authorization Checks
    // -------------------------------------------------------------
    fun isAdmin(): Boolean = _currentUser.value?.role == "ADMIN"

    private fun requireAdminRole() {
        val user = _currentUser.value
        if (user == null || user.role != "ADMIN") {
            throw SecurityException("Access Denied: Administrative privileges are strictly required to perform this action.")
        }
    }

    // -------------------------------------------------------------
    // Admin Operations & CMS
    // -------------------------------------------------------------
    suspend fun getDashboardStats(): DashboardStats {
        return withContext(Dispatchers.IO) {
            val totalUsers = userDao.getTotalUsersCount()
            val activeUsers = userDao.getActiveUsersCount()
            val moviesCount = contentDao.getMoviesCount()
            val seriesCount = contentDao.getSeriesCount()
            val natokCount = contentDao.getNatokCount()
            val filmsCount = contentDao.getFilmsCount()
            val totalViews = contentDao.getTotalViews() ?: 542000L
            val totalDownloads = downloadDao.getTotalDownloadsCount()
            val pendingRequests = contentRequestDao.getPendingRequestsCount()
            val totalAnnouncements = announcementDao.getTotalAnnouncementsCount()
            val activeAnnouncements = announcementDao.getActiveAnnouncementsCount()

            DashboardStats(
                totalUsers = totalUsers,
                activeUsers = activeUsers,
                totalMovies = moviesCount,
                totalSeries = seriesCount,
                totalNatok = natokCount,
                totalFilms = filmsCount,
                totalVideos = moviesCount + seriesCount + natokCount + filmsCount,
                totalViews = totalViews,
                totalDownloads = totalDownloads,
                pendingRequests = pendingRequests,
                totalAnnouncements = totalAnnouncements,
                activeAnnouncements = activeAnnouncements
            )
        }
    }

    // -------------------------------------------------------------
    // Public Announcement Access (Home Screen)
    // -------------------------------------------------------------
    fun getActiveAnnouncements(): Flow<List<Announcement>> = announcementDao.getActiveAnnouncements()

    // -------------------------------------------------------------
    // Admin Announcement Management (CMS)
    // -------------------------------------------------------------
    fun getAllAnnouncementsAdmin(): Flow<List<Announcement>> = announcementDao.getAllAnnouncements()

    suspend fun saveAnnouncement(announcement: Announcement) {
        requireAdminRole()
        firestoreSync.saveAnnouncement(announcement)
    }

    suspend fun deleteAnnouncement(announcementId: String) {
        requireAdminRole()
        firestoreSync.deleteAnnouncement(announcementId)
    }

    suspend fun toggleAnnouncementStatus(announcementId: String, isActive: Boolean) {
        requireAdminRole()
        firestoreSync.toggleAnnouncementStatus(announcementId, isActive)
    }

    fun getAllContentAdmin(): Flow<List<ContentItem>> = contentDao.getAllContentAdmin()

    suspend fun saveContent(item: ContentItem, episodesList: List<Episode> = emptyList()) {
        requireAdminRole()
        firestoreSync.saveContentItem(item, episodesList)
    }

    suspend fun deleteContent(contentId: String) {
        requireAdminRole()
        firestoreSync.deleteContentItem(contentId)
    }

    suspend fun togglePublishContent(contentId: String, isPublished: Boolean) {
        requireAdminRole()
        withContext(Dispatchers.IO) {
            val item = contentDao.getContentById(contentId) ?: return@withContext
            contentDao.updateContent(item.copy(isPublished = isPublished))
            firestoreSync.updateContentField(contentId, "isPublished", isPublished)
        }
    }

    suspend fun toggleFeaturedContent(contentId: String, isFeatured: Boolean) {
        requireAdminRole()
        withContext(Dispatchers.IO) {
            val item = contentDao.getContentById(contentId) ?: return@withContext
            contentDao.updateContent(item.copy(isFeatured = isFeatured))
            firestoreSync.updateContentField(contentId, "isFeatured", isFeatured)
        }
    }

    suspend fun toggleTrendingContent(contentId: String, isTrending: Boolean) {
        requireAdminRole()
        withContext(Dispatchers.IO) {
            val item = contentDao.getContentById(contentId) ?: return@withContext
            contentDao.updateContent(item.copy(isTrending = isTrending))
            firestoreSync.updateContentField(contentId, "isTrending", isTrending)
        }
    }

    // Category Management
    suspend fun saveCategory(category: Category) {
        requireAdminRole()
        firestoreSync.saveCategory(category)
    }

    suspend fun deleteCategory(categoryId: String) {
        requireAdminRole()
        firestoreSync.deleteCategory(categoryId)
    }

    // User Management
    fun getAllUsersAdmin(): Flow<List<User>> = userDao.getAllUsers()

    suspend fun toggleUserStatus(userId: String, currentStatus: String) {
        requireAdminRole()
        val newStatus = if (currentStatus == "ACTIVE") "SUSPENDED" else "ACTIVE"
        userDao.updateUserStatus(userId, newStatus)
    }
}
